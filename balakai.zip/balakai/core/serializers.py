from rest_framework import serializers
from core.models import District, School, Kindergarten

class DistrictSerializer(serializers.ModelSerializer):
    geometry = serializers.SerializerMethodField()

    class Meta:
        model = District
        fields = ['id', 'name', 'geometry']

    def get_geometry(self, obj):
        return obj.geometry.geojson

class SchoolSerializer(serializers.ModelSerializer):
    location = serializers.SerializerMethodField()

    class Meta:
        model = School
        fields = ['id', 'name', 'location', 'capacity', 'current_load']

    def get_location(self, obj):
        return obj.location.geojson

class KindergartenSerializer(serializers.ModelSerializer):
    location = serializers.SerializerMethodField()

    class Meta:
        model = Kindergarten
        fields = ['id', 'name', 'location', 'capacity', 'current_load']

    def get_location(self, obj):
        return obj.location.geojson