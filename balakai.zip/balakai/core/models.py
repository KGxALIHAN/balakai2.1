from django.contrib.gis.db import models
from django.core.validators import MinValueValidator

class District(models.Model):
    name = models.CharField(max_length=100)
    geometry = models.PolygonField()

    def __str__(self):
        return self.name

class PopulationStat(models.Model):
    district = models.ForeignKey(District, on_delete=models.CASCADE, related_name='population_stats')
    year = models.IntegerField(validators=[MinValueValidator(1900)])
    total_population = models.IntegerField(validators=[MinValueValidator(0)])
    school_age_population = models.IntegerField(validators=[MinValueValidator(0)])
    preschool_age_population = models.IntegerField(validators=[MinValueValidator(0)])

    class Meta:
        unique_together = ('district', 'year')

class School(models.Model):
    name = models.CharField(max_length=100)
    district = models.ForeignKey(District, on_delete=models.CASCADE, related_name='schools')
    location = models.PointField()
    capacity = models.IntegerField(validators=[MinValueValidator(0)])
    current_load = models.IntegerField(validators=[MinValueValidator(0)])

    def __str__(self):
        return self.name

class Kindergarten(models.Model):
    name = models.CharField(max_length=100)
    district = models.ForeignKey(District, on_delete=models.CASCADE, related_name='kindergartens')
    location = models.PointField()
    capacity = models.IntegerField(validators=[MinValueValidator(0)])
    current_load = models.IntegerField(validators=[MinValueValidator(0)])

    def __str__(self):
        return self.name