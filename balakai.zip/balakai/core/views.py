from rest_framework.views import APIView
from rest_framework.response import Response
from core.models import District
from core.serializers import DistrictSerializer, SchoolSerializer, KindergartenSerializer
from core.services import forecast_population, analyze_overload, generate_recommendations

class ForecastView(APIView):
    def get(self, request, district_id):
        try:
            district = District.objects.get(id=district_id)
            return Response(forecast_population(district))
        except District.DoesNotExist:
            return Response({'error': 'District not found'}, status=404)

class OverloadView(APIView):
    def get(self, request, district_id):
        try:
            district = District.objects.get(id=district_id)
            return Response(analyze_overload(district))
        except District.DoesNotExist:
            return Response({'error': 'District not found'}, status=404)

class RecommendationsView(APIView):
    def get(self, request, district_id):
        try:
            district = District.objects.get(id=district_id)
            return Response(generate_recommendations(district))
        except District.DoesNotExist:
            return Response({'error': 'District not found'}, status=404)

class MapDataView(APIView):
    def get(self, request):
        districts = DistrictSerializer(District.objects.all(), many=True).data
        schools = SchoolSerializer(School.objects.all(), many=True).data
        kindergartens = KindergartenSerializer(Kindergarten.objects.all(), many=True).data
        return Response({
            'districts': districts,
            'schools': schools,
            'kindergartens': kindergartens
        })